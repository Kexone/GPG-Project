#pragma once

class CubeMap

{

public:
	Texture * map[6];
	CubeMap(const char* file_name[6]);
	~CubeMap();

//	Texture * map(const CubeMap map);

	Color4 get_texel(Vector3 & direction);
};