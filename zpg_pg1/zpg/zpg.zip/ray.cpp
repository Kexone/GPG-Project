#include "stdafx.h"

long long RayOld::no_rays_ = 0;
