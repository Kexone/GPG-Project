#include "cubemap.h"
#include "stdafx.h"

CubeMap::CubeMap(const char* file_name[6]) {
	for (int i = 0; i < 6; i++) {
		map[i] = LoadTexture(file_name[i], -1);
	}
}

CubeMap::~CubeMap() {
	for (int i = 0; i < 6; i++) {
		delete map[i];
		map[i] = NULL;
	}
}

Color4 CubeMap::get_texel(Vector3 & direction) {
	int largestIndex = direction.LargestComponent(true);
	int cubeIndex = largestIndex * 2;

	if (direction.data[largestIndex] < 0)
	{
		cubeIndex += 1;
	}

	float u, v;
	float tmp;
	switch (cubeIndex) {
		case 0:   // POS_X
			tmp = 1.0f / abs(direction.x);
			u = 1 -(direction.y * tmp + 1) * 0.5f;
			v = (direction.z * tmp + 1) * 0.5f;
			break;
		case 1:  // NEG_X
			tmp = 1.0f / abs(direction.x);
			u = (direction.y * tmp + 1) * 0.5f;
			v = (direction.z * tmp + 1) * 0.5f;
			break;
		case 2:  //POS_Y
			tmp = 1.0f / abs(direction.y);
			u = (direction.x * tmp + 1) * 0.5f;
			v = (direction.z * tmp + 1) * 0.5f;
			break;
		case 3: // NEG_Y
			tmp = 1.0f / abs(direction.y);
			u = 1 - (direction.x * tmp + 1) * 0.5f;
			v = (direction.z * tmp + 1) * 0.5f;
			break;
		case 4: //POS_Z
			tmp = 1.0f / abs(direction.z);
			u = (direction.x * tmp + 1) * 0.5f;
			v = 1.0f - (direction.y * tmp + 1) * 0.5f;
			break;
		case 5: //NEG_Z
			tmp = 1.0f / abs(direction.z);
			u = (direction.x *tmp + 1) * 0.5f;
			v = (direction.y * tmp + 1) * 0.5f;
			break;
		default:
			printf ("padam sem");
			return Color4(0, 0, 0, 0);
			;
	}
	Color4 textel = map[cubeIndex]->get_texel(u, v);
	return textel;
		
}